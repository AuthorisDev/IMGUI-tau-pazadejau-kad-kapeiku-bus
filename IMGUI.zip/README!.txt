put all imgui files in there put internalui.h then include to main and add this
near where it says same thing but instead InitImGui it says main


CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)InitImGui, NULL, NULL, NULL);